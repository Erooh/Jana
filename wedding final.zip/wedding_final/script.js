/* ═══════════════════════════════════════════
   SCROLL REVEAL — IntersectionObserver
═══════════════════════════════════════════ */
(function () {
  const els = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          e.target.classList.add('visible');
          observer.unobserve(e.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });
    els.forEach(el => observer.observe(el));
  } else {
    els.forEach(el => el.classList.add('visible'));
  }
})();

/* ═══════════════════════════════════════════
   COUNTDOWN
═══════════════════════════════════════════ */
function updateCountdown() {
  const target = new Date(2026, 5, 30, 0, 0, 0);
  const now    = new Date();
  const diff   = target - now;
  if (diff <= 0) {
    ['cd-days', 'cd-hours', 'cd-mins', 'cd-secs'].forEach(id =>
      document.getElementById(id).textContent = '00');
    return;
  }
  const days  = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins  = Math.floor((diff % 3600000)  / 60000);
  const secs  = Math.floor((diff % 60000)    / 1000);
  document.getElementById('cd-days').textContent  = String(days).padStart(2, '0');
  document.getElementById('cd-hours').textContent = String(hours).padStart(2, '0');
  document.getElementById('cd-mins').textContent  = String(mins).padStart(2, '0');
  document.getElementById('cd-secs').textContent  = String(secs).padStart(2, '0');
}
setInterval(updateCountdown, 1000);
updateCountdown();

/* ═══════════════════════════════════════════
   MUSIC PLAYER
═══════════════════════════════════════════ */
const audio     = document.getElementById('bgMusic');
const iconPlay  = document.getElementById('iconPlay');
const iconPause = document.getElementById('iconPause');
const musicWave = document.getElementById('musicWave');
audio.volume = 0.4;

function setPlayingState(playing) {
  if (playing) {
    iconPlay.style.display  = 'none';
    iconPause.style.display = 'block';
    musicWave.classList.add('playing');
  } else {
    iconPlay.style.display  = 'block';
    iconPause.style.display = 'none';
    musicWave.classList.remove('playing');
  }
}

let autoPlayDone = false;
function tryAutoPlay() {
  if (autoPlayDone) return;
  autoPlayDone = true;
  audio.play().then(() => setPlayingState(true)).catch(() => {});
}

document.addEventListener('click',      tryAutoPlay, { once: true, passive: true });
document.addEventListener('touchstart', tryAutoPlay, { once: true, passive: true });
document.addEventListener('scroll',     tryAutoPlay, { once: true, passive: true });

window.addEventListener('load', () => {
  audio.play().then(() => {
    autoPlayDone = true;
    setPlayingState(true);
  }).catch(() => {});
});

window.togglePlay = function () {
  if (audio.paused) {
    audio.play().then(() => setPlayingState(true)).catch(() => {});
  } else {
    audio.pause();
    setPlayingState(false);
  }
};

/* ═══════════════════════════════════════════
   VENUE BUTTON — touch support for mobile
═══════════════════════════════════════════ */
document.querySelectorAll('.venue-btn').forEach(btn => {
  btn.addEventListener('touchstart', () => btn.classList.add('touched'), { passive: true });
  btn.addEventListener('touchend', () => {
    setTimeout(() => btn.classList.remove('touched'), 600);
  }, { passive: true });
});

/* ═══════════════════════════════════════════
   RSVP — show/hide gift field
═══════════════════════════════════════════ */
document.getElementById('f-attend').addEventListener('change', function () {
  const gf = document.getElementById('giftField');
  if (this.value === 'Այո, կմասնակցեմ') {
    gf.style.display = 'flex';
  } else {
    gf.style.display = 'none';
    document.getElementById('f-gift').value = '';
  }
});

/* ═══════════════════════════════════════════
   RSVP SUBMIT
═══════════════════════════════════════════ */
window.submitRSVP = function () {
  const name     = document.getElementById('f-name').value.trim();
  const side     = document.getElementById('f-side').value;
  const guests   = document.getElementById('f-guests').value;
  const attend   = document.getElementById('f-attend').value;
  const gift     = document.getElementById('f-gift').value;
  const attending = attend === 'Այո, կմասնակցեմ';

  // Reset borders
  ['f-name', 'f-side', 'f-guests', 'f-attend', 'f-gift'].forEach(id =>
    document.getElementById(id).style.borderColor = '');

  let ok = true;
  if (!name)               { document.getElementById('f-name').style.borderColor   = 'rgba(197,146,42,0.8)'; ok = false; }
  if (!side)               { document.getElementById('f-side').style.borderColor   = 'rgba(197,146,42,0.8)'; ok = false; }
  if (!guests)             { document.getElementById('f-guests').style.borderColor = 'rgba(197,146,42,0.8)'; ok = false; }
  if (!attend)             { document.getElementById('f-attend').style.borderColor = 'rgba(197,146,42,0.8)'; ok = false; }
  if (attending && !gift)  { document.getElementById('f-gift').style.borderColor   = 'rgba(197,146,42,0.8)'; ok = false; }
  if (!ok) return;

  fetch('https://formsubmit.co/ajax/erooo661@gmail.com', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify({
      _subject: `RSVP՝ ${name} — Լեռնիկ & Լիանա`,
      _captcha: 'false',
      _template: 'table',
      name, side, guests, attend, gift: gift || '—'
    })
  }).catch(() => {});

  const form    = document.getElementById('rsvpForm');
  const success = document.getElementById('rsvpSuccess');
  form.style.transition = 'opacity 0.4s';
  form.style.opacity    = '0';
  setTimeout(() => {
    form.style.display    = 'none';
    success.style.display = 'block';
    success.style.opacity = '0';
    requestAnimationFrame(() => {
      success.style.transition = 'opacity 0.8s';
      success.style.opacity    = '1';
    });
  }, 400);
};
